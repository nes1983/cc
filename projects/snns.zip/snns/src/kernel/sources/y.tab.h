typedef union {
       float value;   /* allgemeine Zahl */   
        char    *name;          /* allgemeiner String */
       struct {
             int  v;
             int  r;
       }     version;    /* Versionsnummer #.# */
} YYSTYPE;
#define        L_BRACKET      258
#define        R_BRACKET      259
#define        VERSION_HEADER 260
#define        GENERATED_AT   261
#define        NO_OF_PATTERN  262
#define        NO_OF_INPUT    263
#define        NO_OF_OUTPUT   264
#define        NO_OF_VAR_IDIM 265
#define        NO_OF_VAR_ODIM 266
#define        MAXIMUM_IDIM   267
#define        MAXIMUM_ODIM   268
#define        NO_OF_CLASSES  269
#define        CLASS_REDISTRIB        270
#define        REMAPFUNCTION  271
#define        REMAP_PARAM    272
#define        ERROR  273
#define        PATTERNEND     274
#define        PATTERNNOCLASS 275
#define        NUMBER 276
#define        NAME   277
#define        V_NUMBER       278
extern YYSTYPE pplval;
