/*
 * @(#)DefaultTextUI.java      1.85 01/12/03
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package javax.swing.text;
import javax.swing.plaf.basic.BasicTextUI;
/**
 * <p>
 * This class has been deprecated and should no longer be used.
 * The basis of the various TextUI implementations can be found
 * in the javax.swing.plaf.basic package and the class
 * BasicTextUI replaces this class.
 *
 * @deprecated
 */
public abstract class DefaultTextUI extends BasicTextUI { }
