/* repout */
char report[81];
/* report - report line for output */
