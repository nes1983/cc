/* precin */
int unitno;
long int precno;
int regist;
int congr;
int senate;
int distct;
int college;
int vothow;
#define MACHINE 1
#define PUNCHCARD 2
#define PAPER 3
int repre[2];
int commis[5];
