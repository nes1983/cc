/* state */
int outpos,nform;
long int form[6][21];
char head0[131];
char head1[131],head2[131],head3[131];
#define CAND 0
#define POSN 1
#define NVOTE 2
#define TOTAL 3
#define UNITTOT 4
#define WARDTOT 5
#define LANDSCAPE 56
