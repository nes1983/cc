package com.stradivari.util;

import java.math.RoundingMode;

public class Math {
	static final int[] powers_Of_10 = { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000 };
	static final int[] half_Powers_Of_10 = { 3, 31, 316, 3162, 31622, 316227, 3162277, 31622776, 316227766,
			Integer.MAX_VALUE };
	static final byte[] MAX_LOG_10_FOR_LEADING_ZEROS = { 9, 9, 9, 8, 8, 8, 7, 7, 7, 6, 6, 6, 6, 5, 5, 5, 4, 4, 4, 3, 3,
			3, 3, 2, 2, 2, 1, 1, 1, 0, 0, 0, 0 };

	public static int log10(int x, RoundingMode mode) {
		int logFloor = log10Floor(x);
		int floorPow = powers_Of_10[logFloor];
		switch (mode) {
		case UNNECESSARY:
			checkRoundingUnnecessary(x == floorPow);
			// fall through
		case FLOOR:
		case DOWN:
			return logFloor;
		case CEILING:
		case UP:
			return (x == floorPow) ? logFloor : logFloor + 1;
		case HALF_DOWN:
		case HALF_UP:
		case HALF_EVEN:
			// sqrt(10) is irrational, so log10(x) - logFloor is never exactly
			// 0.5
			return (x <= half_Powers_Of_10[logFloor]) ? logFloor : logFloor + 1;
		default:
			throw new AssertionError();
		}
	}

	private static int log10Floor(int x) {
		int y = MAX_LOG_10_FOR_LEADING_ZEROS[Integer.numberOfLeadingZeros(x)];
		int sgn = (x - powers_Of_10[y]) >>> (Integer.SIZE - 1);
		return y - sgn;
	}

	static void checkRoundingUnnecessary(boolean condition) {
		if (!condition) {
			throw new ArithmeticException("mode was UNNECESSARY, but rounding was necessary");
		}
	}

	static int checkPositive(String role, int x) {
		if (x <= 0) {
			throw new IllegalArgumentException(role + " (" + x + ") must be > 0");
		}
		return x;
	}
}
