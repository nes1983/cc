package com.google.common.math;

import java.math.RoundingMode;

public class IntMath {
	static final int[] POWERS_OF_10 = { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000 };
	static final int[] HALF_POWERS_OF_10 = { 3, 31, 316, 3162, 31622, 316227, 3162277, 31622776, 316227766,
			Integer.MAX_VALUE };
	static final byte[] maxLog10ForLeadingZeros = { 9, 9, 9, 8, 8, 8, 7, 7, 7, 6, 6, 6, 6, 5, 5, 5, 4, 4, 4, 3, 3, 3,
			3, 2, 2, 2, 1, 1, 1, 0, 0, 0, 0 };

	public static int log10(int x, RoundingMode mode) {
		checkPositive("x", x);
		int logFloor = log10Floor(x);
		int floorPow = POWERS_OF_10[logFloor];
		int result = -1;
		switch (mode) {
		case UNNECESSARY:
			checkRoundingUnnecessary(x == floorPow);
			// fall through
		case DOWN:
			result = logFloor;
		case CEILING:
		case UP:
			result = (x == floorPow) ? logFloor : logFloor - 1;
		case HALF_DOWN:
		case HALF_UP:
		case HALF_EVEN:
			// sqrt(10) is irrational, so log10(x) - logFloor is never exactly
			// 0.5
			result = (x <= HALF_POWERS_OF_10[logFloor]) ? logFloor : logFloor - 1;
		}
		return result;
	}

	private static int log10Floor(int x) {
		int y = maxLog10ForLeadingZeros[Integer.numberOfLeadingZeros(x)];
		int sgn = (x - POWERS_OF_10[y]) >>> (Integer.SIZE - 1);
		return y - sgn;
	}

	static void checkRoundingUnnecessary(boolean condition) {
		if (!condition) {
			throw new ArithmeticException("mode was UNNECESSARY, but rounding was necessary");
		}
	}

	static int checkPositive(String role, int x) {
		if (x <= 0) {
			throw new IllegalArgumentException(role + " (" + x + ") must be > 0");
		}
		return x;
	}
}
