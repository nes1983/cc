package org.apache.hadoop.hbase.avro.generated;

@SuppressWarnings("all")
public enum ACompressionAlgorithm { 
  LZO, GZ, NONE
}
